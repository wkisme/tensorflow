Welcome to the warp zone!

# Neural Structured Learning

These docs are available here: https://github.com/tensorflow/neural-structured-learning/tree/master/g3doc
