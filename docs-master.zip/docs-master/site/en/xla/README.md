Welcome to the warp zone!

# XLA: Accelerated Linear Algebra

These docs are available here: https://github.com/tensorflow/tensorflow/tree/master/tensorflow/compiler/xla/g3doc
