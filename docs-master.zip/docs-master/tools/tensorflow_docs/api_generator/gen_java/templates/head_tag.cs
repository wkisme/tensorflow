  <head>
    <title><?cs if:page.title ?><?cs var:page.title ?><?cs /if ?></title>
    <meta name="book_path" value="<?cs var:book.path ?>" />
    <meta name="project_path" value="<?cs var:project.path ?>" />
    <link rel="stylesheet" href="/api_docs/java/reference/screen.css">
  </head>
